// Stores data for Chord Diagram
var chordData;

// Variables for the Chord Diagram visualization instance
var chordDiagram;

var id;

// Main

queue()
    .defer(d3.json, "data/state-geo.json")
    .defer(d3.csv, "data/state-hpi.csv")
    .defer(d3.csv, "data/state-comparison.csv")
    .await(loadData);


// Stores Map and Spider Diagram Data
var stateHousing, stateTopo, stateProperties, clickedState, firstState, secondState, firstClickedStateRegion = "", secondClickedStateRegion = "";

// Spider diagram color variable
var colorCount = 0;

// Used to keep track of number of states selected (max 2)
var clickCount = 0;

// Variables for the Map and Spider Diagram visualization instances
var choroplethMap, spiderDiagram, hpiDiagram ;

function loadData(error, stateGeo, stateHPI, stateComp) {

    // Save topoJSON data in global variable
    stateTopo = stateGeo;

    // Clean HPI data at state level
    stateHPI.forEach(function(el){
        cleanHPI(el);
    });

    // Save HPI data at state level in global variable
    stateHousing = stateHPI;

    // Clean state comparison data
    stateComp.forEach(function(el){
       cleanComp(el);
    });

    // Save comparison data at state level in global variable
    stateProperties = stateComp;

    //debugging

    createVis();
    createBarChart();

}


// Loads Data for Chord Diagram
function loadChordData() {
    d3.csv("data/US_House_Sales_byRegion.csv", function(error, csv){
        if(!error){
            chordData = csv;
            createChordVis();
        }
    });
}


function createVis() {

    choroplethMap = new ChoroplethMap("map",stateHousing,stateTopo);

    spiderDiagram = new SpiderDiagram("spider-diagram");

    // When user clicks on state, fetch comparison data
    choroplethMap.stateMap.on("click", function(d) {

       var code = this.__data__.properties.STUSPS;

       var userState = fetchComp(code);

       var path = spiderDiagram.drawPolygon(userState, spiderDiagram.baseCase);


        colorCount += 1;

        spiderDiagram.svg.append("path")
            .attr("d", path)
            .attr("class", "polygon")
            .style("fill", spiderDiagram.colors[colorCount%12])
            .style("opacity", "0.6")
            .style("stroke-width", "2");

        //spiderDiagram.stateName.text(clickedState.name);
    });

}

function createChordVis() {
    chordDiagram =  new ChordDiagram("chord", chordData)
}

// Updates Chord Visualization
function updateChordVisualization() {
    ChordDiagram.prototype.updateVis();
    loadChordData();
}

function cleanHPI(element) {
    element["index_nsa"] = +element["index_nsa"];
}

function cleanComp(element) {
    element["state"] = element["state"].replace(/\./g , "");
    element["gdp"] = +element["gdp"] / 1000; // in billion $
    element["hdi"] = +element["hdi"];
    element["median_house_price"] = +element["median_house_price"];
    element["median_household_income"] = +element["median_household_income"];
    element["median_rent"] = +element["median_rent"];
    element["population"] = +element["population"];
}

function fetchComp(code) {

    if (clickCount < 2){

        var stateProp = stateProperties.filter(function(el) {return el["state_code"] === code});
        var stateIndex = stateHousing.filter(function(el) {return (el.place_id === code) && (el.period === "4") && (el.yr === "2015")});

        clickedState = {};

        clickedState.name = stateProp[0].state;
        clickedState.GDP = stateProp[0].gdp;
        clickedState.HDI = stateProp[0].hdi;
        clickedState.median_house_price = stateProp[0].median_house_price;
        clickedState.median_rent = stateProp[0].median_rent;
        clickedState.household_income = stateProp[0].median_household_income;
        clickedState.population = stateProp[0].population;
        clickedState.house_price_index = stateIndex[0].index_nsa;

        clickCount += 1;

        // Stop the user from choosing the same two state
        if (clickCount == 1){
            firstState = stateProp[0].state;
        }
        else{
            secondState = stateProp[0].state;
            if (firstState == secondState){
                alert("Please choose a different second state to compare.");
                clickCount -= 1;
                end();
            }
        }

        document.getElementById("state" + clickCount).textContent=stateProp[0].state;
        document.getElementById("mhp" + clickCount).textContent= "$" + stateProp[0].median_house_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        document.getElementById("md" + clickCount).textContent= "$" + stateProp[0].median_rent.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        document.getElementById("pi" + clickCount).textContent= (stateProp[0].median_house_price/stateProp[0].median_household_income).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        document.getElementById("hi" + clickCount).textContent= "$" + stateProp[0].median_household_income.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        document.getElementById("hd" + clickCount).textContent=stateProp[0].hdi.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        document.getElementById("p" + clickCount).textContent=stateProp[0].population.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        document.getElementById("gdp" + clickCount).textContent=stateProp[0].gdp.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        document.getElementById("pidx" + clickCount).textContent=stateIndex[0].index_nsa.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

        if (document.getElementById("chord")){

            if (clickCount == 1){
                firstClickedStateRegion = stateProp[0].region;
                document.getElementById("state" + clickCount).textContent=stateProp[0].state + " - (" + firstClickedStateRegion + ")";
            }
            else {
                secondClickedStateRegion = stateProp[0].region;
                document.getElementById("state" + clickCount).textContent=stateProp[0].state + " - (" + secondClickedStateRegion + ")";
            }

            updateChordVisualization();
        }

        return clickedState;

    }
    else{
        alert("Maximum of two states. Please click reset in order to make additional comparisons");

    }
}

function reset() {

    spiderDiagram.svg.selectAll(".polygon").remove();
    clickCount = 0;
    firstClickedStateRegion = "";
    secondClickedStateRegion = "";

    for (var i = 1; i < 3; i++) {
        document.getElementById("state" + i).textContent= "State" + i;
        document.getElementById("mhp" + i).textContent="";
        document.getElementById("md" + i).textContent="";
        document.getElementById("pi" + i).textContent="";
        document.getElementById("hi" + i).textContent="";
        document.getElementById("hd" + i).textContent="";
        document.getElementById("p" + i).textContent="";
        document.getElementById("gdp" + i).textContent="";
        document.getElementById("pidx" + i).textContent="";
    }

    if (document.getElementById("chord")){
        updateChordVisualization();
    }
}


// Changes Visualization to Chord Diagram
function changeToChordVis(){

    reset();

    if (!document.getElementById("chord")) {

        var parent = document.getElementById("dashboard");
        var child;

        if (document.getElementById("spider-diagram")) {
            child = document.getElementById("spider-diagram")
        } else if (document.getElementById("chord")) {
            child = document.getElementById("chord")
        }

        var chord = document.createElement("div");
        var dropDiv = document.createElement("div");
        var dropdown = document.createElement("select")
        var buttonDiv = document.createElement("div");
        var button = document.createElement("input");

        var op02 = new Option();
        var op03 = new Option();
        var op04 = new Option();
        var op05 = new Option();
        var op06 = new Option();
        var op07 = new Option();
        var op08 = new Option();
        var op09 = new Option();
        var op10 = new Option();
        var op11 = new Option();
        var op12 = new Option();
        var op13 = new Option();
        var op14 = new Option();
        var op15 = new Option();

        dropDiv.setAttribute("id", "drop-div");
        dropDiv.setAttribute("class", "col-xs-6");

        chord.setAttribute("style","height:500px");

        dropdown.setAttribute("id", "sort-type");
        dropdown.setAttribute("class", "form-control row");
        dropdown.onchange = updateChordVisualization;

        op15.value = 2015;
        op15.text = "2015";
        dropdown.options.add(op15);

        op14.value = 2014;
        op14.text = "2014";
        dropdown.options.add(op14);

        op13.value = 2013;
        op13.text = "2013";
        dropdown.options.add(op13);

        op12.value = 2012;
        op12.text = "2012";
        dropdown.options.add(op12);

        op11.value = 2011;
        op11.text = "2011";
        dropdown.options.add(op11);


        op10.value = 2010;
        op10.text = "2010";
        dropdown.options.add(op10);

        op09.value = 2009;
        op09.text = "2009";
        dropdown.options.add(op09);

        op08.value = 2008;
        op08.text = "2008";
        dropdown.options.add(op08);

        op07.value = 2007;
        op07.text = "2007";
        dropdown.options.add(op07);

        op06.value = 2006;
        op06.text = "2006";
        dropdown.options.add(op06);


        op05.value = 2005;
        op05.text = "2005";
        dropdown.options.add(op05);

        op04.value = 2004;
        op04.text = "2004";
        dropdown.options.add(op04);

        op03.value = 2003;
        op03.text = "2003";
        dropdown.options.add(op03);

        op02.value = 2002;
        op02.text = "2002";
        dropdown.options.add(op02);

        chord.setAttribute("id", "chord");

        parent.removeChild(child);

        parent.appendChild(chord);

        document.getElementById("chord").appendChild(buttonDiv);

        document.getElementById("chord").appendChild(dropDiv);

        document.getElementById("drop-div").appendChild(dropdown);

        loadChordData();
    }


}

function changeToSpiderVis(){

    if (!document.getElementById("spider-diagram")) {

        reset();

        var parent = document.getElementById("dashboard");
        var child;

        if (document.getElementById("spider-diagram")) {
            child = document.getElementById("spider-diagram")
        } else if (document.getElementById("chord")) {
            child = document.getElementById("chord")
        }

        var spider = document.createElement("div");
        var spiderSvg = document.createElement("svg");
        var buttonDiv = document.createElement("div");
        var button = document.createElement("input");

        spider.setAttribute("id", "spider-diagram");
        spider.setAttribute("style","height:500px");

        parent.removeChild(child);

        parent.appendChild(spider);


        document.getElementById("spider-diagram").appendChild(spiderSvg);


        spiderDiagram = new SpiderDiagram("spider-diagram");
    }

}

function createBarChart(){

        hpiDiagram = new HPIDiagram("bar-chart",stateHousing);

}

function updateBarChart(){

    var bar_parent = document.getElementById("bar-chart");
    bar_parent.removeChild(bar_parent.firstChild);

    var quarter_selected = $('#quarter-select option:selected').val();
    var year_selected = $('#year-select option:selected').val();

    console.log("updateBarChart called");
    console.log(quarter_selected);
    console.log(year_selected);

    hpiDiagram = new HPIDiagram("bar-chart", stateHousing, quarter_selected, year_selected);
}

// tool-tip for html elements
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});


// filter portfolio(census regions) by northeast
var $container = $('.isotopeWrapper');
$container.isotope({
    filter: '.northeast'
});


// get button id (used for modal)
$(".button").click(function() {
  id = this.id;
});

// displays a popup modal with state-level statistics
function modal(){

    d3.csv("data/US_States_Facts.csv", function(error,data){

        var stateSelected = data.filter(function (d) {
            return d.State == id;
        });


        document.getElementById("state").textContent= stateSelected[0].State;
        document.getElementById("p").textContent= stateSelected[0]["Population estimates, July 1, 2015,  (V2015)"].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        document.getElementById("mhi").textContent= "$" + stateSelected[0]["Median household income (in 2014 dollars), 2010-2014"].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        document.getElementById("hu").textContent= stateSelected[0]["Housing units,  July 1, 2014,  (V2014)"].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        document.getElementById("oo").textContent= stateSelected[0]["Owner-occupied housing unit rate, 2010-2014"] + "%";
        document.getElementById("mv").textContent= "$" + stateSelected[0]["Median value of owner-occupied housing units, 2010-2014"].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        document.getElementById("mgs").textContent= "$" + stateSelected[0]["Median gross rent"].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");


        var modal = document.getElementById('myModal');

        // Get the button that opens the modal
        var btn = document.getElementById(id);

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks the button, open the modal
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    });
}



(function ($) {

	$(window).scroll(function(){
		if ($(this).scrollTop() > 100) {
			$('.scrollup').fadeIn();
			} else {
				$('.scrollup').fadeOut();
			}
		});
		$('.scrollup').click(function(){
			$("html, body").animate({ scrollTop: 0 }, 1000);
				return false;
		});
	
	// local scroll
	jQuery('.navbar').localScroll({hash:true, offset: {top: 0},duration: 800, easing:'easeInOutExpo'});

	
	// portfolio
    if($('.isotopeWrapper').length){

        var $container = $('.isotopeWrapper');
        var $resize = $('.isotopeWrapper').attr('id');
        // initialize isotope
        
        $container.isotope({
            itemSelector: '.isotopeItem',
            resizable: false, // disable normal resizing
            masonry: {
                columnWidth: $container.width() / $resize
            }


            
        });

        $('#filter a').click(function(){



            $('#filter a').removeClass('current');
            $(this).addClass('current');
            var selector = $(this).attr('data-filter');
            $container.isotope({
                filter: selector,
                animationOptions: {
                    duration: 1000,
                    easing: 'easeOutQuart',
                    queue: false
                }
            });
            return false;
        });
        
        
        $(window).smartresize(function(){
            $container.isotope({
                // update columnWidth to a percentage of container width
                masonry: {
                    columnWidth: $container.width() / $resize
                }
            });
        });
        

}  


	// fancybox
	jQuery(".fancybox").fancybox();


	if (Modernizr.mq("screen and (max-width:1024px)")) {
			jQuery("body").toggleClass("body");
			
	} else {
		var s = skrollr.init({
			mobileDeceleration: 1,
			edgeStrategy: 'set',
			forceHeight: true,
			smoothScrolling: true,
			smoothScrollingDuration: 300,
				easing: {
					WTF: Math.random,
					inverted: function(p) {
						return 1-p;
					}
				}
			});	
	}



	//scroll menu
	jQuery('.appear').appear();
	jQuery(".appear").on("appear", function(data) {
			var id = $(this).attr("id");
			jQuery('.nav li').removeClass('active');
			jQuery(".nav a[href='#" + id + "']").parent().addClass("active");					
		});


		//parallax
        var isMobile = false;

        if(Modernizr.mq('only all and (max-width: 1024px)') ) {
            isMobile = true;
        }

        
        if (isMobile == false && ($('#parallax1').length  ||isMobile == false &&  $('#parallax2').length ||isMobile == false &&  $('#testimonials').length))
        {


            $(window).stellar({
                responsive:true,
                scrollProperty: 'scroll',
                parallaxElements: false,
                horizontalScrolling: false,
                horizontalOffset: 0,
                verticalOffset: 0
            });

        }
	
	//nicescroll
	$("html").niceScroll({zindex:999,cursorborder:"",cursorborderradius:"2px",cursorcolor:"#191919",cursoropacitymin:.5});
	function initNice() {
		if($(window).innerWidth() <= 960) {
			$('html').niceScroll().remove();
		} else {
			$("html").niceScroll({zindex:999,cursorborder:"",cursorborderradius:"2px",cursorcolor:"#191919",cursoropacitymin:.5});
		}
	}
	$(window).load(initNice);
	$(window).resize(initNice);

})(jQuery);